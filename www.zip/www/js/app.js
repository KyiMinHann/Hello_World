(function(){
  'use strict';
  var module = angular.module('app', ['onsen','ngResource']);

  module.controller('AppController', function($scope, $data) {
	  
	  
  });

  module.controller('DetailController', function($scope,$http, $data,$sce) {
    $scope.item = $data.selectedItem;
    var url =$data.selectedItem.url+'&json=1&include=content';
    
    $http.get(url,{ cache: true}).success(function(data1, status, headers, config) {
    	
  	  $scope.myHTML  = $sce.trustAsHtml(data1.post.content);
    });
    
  });
  
  module.controller('Page1Controller', function($scope,$http,$data) {
	  
	  $data.url = "http://www.amyothahluttaw.gov.mm/?cat=538&json=1&include=id,title,thumbnail,url";
	  if($data.url){
	      $http.get($data.url,{ cache: true}).success(function(data1, status, headers, config) {
	    	  $data.items = data1.posts;
	    	  $scope.items  = $data.items;
	    	
	      });
	  }
    
      
	
    $scope.showDetail = function(index) {
      var selectedItem = $data.items[index];
      $data.selectedItem = selectedItem;
      $scope.navi.pushPage('detail.html', {title : selectedItem.title});
    };
    
  });
  
  module.controller('Page2Controller', function($scope,$http,$data) {
	  
	  $data.url = "http://www.amyothahluttaw.gov.mm/?cat=838&json=1&include=id,title,thumbnail,url";
	  if($data.url){
	      $http.get($data.url,{ cache: true}).success(function(data1, status, headers, config) {
	    	  $data.items = data1.posts;
	    	  $scope.items  = $data.items;
	    	
	      });
	  }
    
    $scope.showDetail = function(index) {
      var selectedItem = $data.items[index];
      $data.selectedItem = selectedItem;
      $scope.navi.pushPage('detail.html', {title : selectedItem.title});
    };
    
  });
  
  module.controller('Page3Controller', function($scope,$http,$data) {
	  
	  $data.url = "http://www.amyothahluttaw.gov.mm/?cat=840&json=1&include=id,title,thumbnail,url";
	  if($data.url){
	      $http.get($data.url,{ cache: true}).success(function(data1, status, headers, config) {
	    	  $data.items = data1.posts;
	    	  $scope.items  = $data.items;
	    	
	      });
	  }
    
    $scope.showDetail = function(index) {
      var selectedItem = $data.items[index];
      $data.selectedItem = selectedItem;
      $scope.navi.pushPage('detail.html', {title : selectedItem.title});
    };
    
  });
  
 module.controller('Page4Controller', function($scope,$http,$data) {
	  
	  $data.url = "http://www.amyothahluttaw.gov.mm/?cat=540&json=1&include=id,title,thumbnail,url";
	  if($data.url){
	      $http.get($data.url,{ cache: true}).success(function(data1, status, headers, config) {
	    	  $data.items = data1.posts;
	    	  $scope.items  = $data.items;
	    	
	      });
	  }
    
    $scope.showDetail = function(index) {
      var selectedItem = $data.items[index];
      $data.selectedItem = selectedItem;
      $scope.navi.pushPage('detail.html', {title : selectedItem.title});
    };
    
  });
 
 
 module.controller('Page5Controller', function($scope,$http,$data) {
	  
	  $data.url = "http://www.amyothahluttaw.gov.mm/?cat=542&json=1&include=id,title,thumbnail,url";
	  if($data.url){
	      $http.get($data.url,{ cache: true}).success(function(data1, status, headers, config) {
	    	  $data.items = data1.posts;
	    	  $scope.items  = $data.items;
	    	
	      });
	  }
   
   $scope.showDetail = function(index) {
     var selectedItem = $data.items[index];
     $data.selectedItem = selectedItem;
     $scope.navi.pushPage('detail.html', {title : selectedItem.title});
   };
   
 });
 

  module.factory('$data', function($http) {
      var data = {};
      return data;
  });
  

  
})();

